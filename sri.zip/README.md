# SRI_project_2024

## Integrantes
* Frank Perez Fleita
* Alejandro Alvarez Lamazares
