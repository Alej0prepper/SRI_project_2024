
from Filtrado_colaborativo_basado_en_items import predict_ratings as get_collaborative_recommendations
from Recomendacion_basada_en_contenido import recommend_movies as get_content_based_recommendations
from Recomendacion_basada_en_demografia_lite import recommend_by_demographics as get_demographic_recommendations

# Define weights for each recommendation technique
WEIGHTS = {
    'collaborative': 0.5,
    'content': 0.3,
    'demographic': 0.2
}

def weighted_hybrid_recommendations(user_id):
    # Get recommendations from each method
    collaborative_scores = get_collaborative_recommendations(user_id)
    content_scores = get_content_based_recommendations(user_id)
    demographic_scores = get_demographic_recommendations(user_id)

    # Initialize a dictionary to store combined scores
    combined_scores = {}

    # Combine scores with weights
    for item in set(collaborative_scores.keys()).union(content_scores.keys(), demographic_scores.keys()):
        combined_scores[item] = (
            WEIGHTS['collaborative'] * collaborative_scores.get(item, 0) +
            WEIGHTS['content'] * content_scores.get(item, 0) +
            WEIGHTS['demographic'] * demographic_scores.get(item, 0)
        )

    # Sort items by combined score in descending order
    sorted_items = sorted(combined_scores.items(), key=lambda x: x[1], reverse=True)

    # Return the top recommendations
    return sorted_items

if __name__ == "__main__":
    user_id = 1  # Example user ID
    recommendations = weighted_hybrid_recommendations(user_id)
    print("Top recommendations (item_id, score):")
    for item_id, score in recommendations:
        print(f"Item {item_id}: {score:.4f}")
